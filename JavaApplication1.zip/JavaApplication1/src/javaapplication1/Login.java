
package javaapplication1;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.SQLException;


public class Login extends javax.swing.JFrame {
private User user = new User(); 
    public Login() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        UserLogin = new javax.swing.JLabel();
        Nom = new javax.swing.JLabel();
        MDP = new javax.swing.JLabel();
        Nom_field = new javax.swing.JTextField();
        MDP_field = new javax.swing.JTextField();
        BTN_sinscrire = new javax.swing.JButton();
        text = new javax.swing.JLabel();
        BTN_connecter = new javax.swing.JButton();

        jButton2.setText("jButton2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jPanel2.setBackground(new java.awt.Color(255, 0, 0));

        UserLogin.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        UserLogin.setForeground(new java.awt.Color(255, 255, 255));
        UserLogin.setText("User Login");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(UserLogin)
                .addGap(119, 119, 119))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(UserLogin)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        Nom.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        Nom.setText("Nom d'utulisateur :");

        MDP.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        MDP.setText("Mot de passe :");

        Nom_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Nom_fieldActionPerformed(evt);
            }
        });

        BTN_sinscrire.setBackground(new java.awt.Color(204, 204, 255));
        BTN_sinscrire.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        BTN_sinscrire.setForeground(new java.awt.Color(0, 51, 255));
        BTN_sinscrire.setText("S'inscrire");
        BTN_sinscrire.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        BTN_sinscrire.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTN_sinscrireActionPerformed(evt);
            }
        });

        text.setBackground(new java.awt.Color(255, 102, 51));
        text.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        text.setForeground(new java.awt.Color(51, 0, 102));
        text.setText("Vous n'avez pas de compte ? Inscriez-vous");

        BTN_connecter.setBackground(new java.awt.Color(204, 204, 255));
        BTN_connecter.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        BTN_connecter.setForeground(new java.awt.Color(255, 0, 0));
        BTN_connecter.setText("Connecter");
        BTN_connecter.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        BTN_connecter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTN_connecterActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(text, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Nom)
                            .addComponent(MDP, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Nom_field, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
                            .addComponent(MDP_field))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(96, 96, 96)
                        .addComponent(BTN_sinscrire, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(BTN_connecter, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Nom)
                    .addComponent(Nom_field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MDP)
                    .addComponent(MDP_field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(BTN_connecter)
                .addGap(18, 18, 18)
                .addComponent(text, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BTN_sinscrire)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Nom_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Nom_fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Nom_fieldActionPerformed

    private void BTN_sinscrireActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTN_sinscrireActionPerformed
         Inscription I = new Inscription(); // Remplacez NouvelleFenetre par le nom de votre classe de fenêtre
                I.setVisible(true);
                dispose();
    }//GEN-LAST:event_BTN_sinscrireActionPerformed

    private void BTN_connecterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTN_connecterActionPerformed
                                          
    String username = Nom_field.getText(); // Get the username from the text field
    String password = MDP_field.getText(); // Get the password from the text field
    
    // Check if username and password fields are not empty
    if (!username.isEmpty() && !password.isEmpty()) {
        // Set the username and password in the User object
        user.setNom(username);
        user.setMdp(password);
        
        // Call the authenticate function to check credentials
        if (user.authenticate()) {
            // Authentication successful, show a success message and proceed to next screen
            JOptionPane.showMessageDialog(null, "Authentication successful!");
            // Add your code here to navigate to the next screen or perform other actions
            MainGUI  I= new MainGUI(); // Remplacez NouvelleFenetre par le nom de votre classe de fenêtre
                I.setVisible(true);
                dispose();
        } else {
            // Authentication failed, show an error message
            JOptionPane.showMessageDialog(null, "Authentication failed. Invalid username or password.");
        }
    } else {
        // Username or password fields are empty, show an error message
        JOptionPane.showMessageDialog(null, "Please enter both username and password.");
    }



    }//GEN-LAST:event_BTN_connecterActionPerformed

      

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTN_connecter;
    private javax.swing.JButton BTN_sinscrire;
    private javax.swing.JLabel MDP;
    private javax.swing.JTextField MDP_field;
    private javax.swing.JLabel Nom;
    private javax.swing.JTextField Nom_field;
    private javax.swing.JLabel UserLogin;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel text;
    // End of variables declaration//GEN-END:variables
}
