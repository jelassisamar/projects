package javaapplication1;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
public class User {
    private String nom;
    private String mdp;

    public User(String nom, String mdp) {
        this.nom = nom;
        this.mdp = mdp;
    }

    public User() {

    }
    public void setNom(String nom){
        this.nom=nom;
    }

    public void setMdp(String mdp){
        this.mdp=mdp;
    }

    public boolean authenticate() {
        PreparedStatement ps;
        ResultSet rs;

        try {
            MY_Connection mconnection = new MY_Connection();
            String selectQuery = "SELECT * FROM `users` WHERE `nom`=? AND `mdp`=?";
            ps = mconnection.createConnection().prepareStatement(selectQuery);
            ps.setString(1, this.nom);
            ps.setString(2, this.mdp);

            rs = ps.executeQuery(); // Exécuter la requête

            if (rs.next()) {
                // L'utilisateur est authentifié
                rs.close();
                ps.close();
                mconnection.createConnection().close();
                return true;
            } else {
                rs.close();
                ps.close();
                mconnection.createConnection().close();
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erreur de connexion : " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
        public void registerUser() {
        PreparedStatement ps;

        if (nom.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Enter your name", "Empty Name", JOptionPane.WARNING_MESSAGE);
        } else if (mdp.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Enter your password", "Empty Password", JOptionPane.WARNING_MESSAGE);
        } else {
            try {
                MY_Connection mconnection = new MY_Connection();
                String insertQuery = "INSERT INTO `users`(`nom`, `mdp`) VALUES (?, ?)";
                ps = mconnection.createConnection().prepareStatement(insertQuery);
                ps.setString(1, nom);
                ps.setString(2, mdp);

                int result = ps.executeUpdate(); // Execute the insertion query

                if (result > 0) {
                    JOptionPane.showMessageDialog(null, "Registration successful!");
                    // Optionally, you can add code here to navigate to the main GUI or another page
                } else {
                    JOptionPane.showMessageDialog(null, "Error during registration", "Error", JOptionPane.ERROR_MESSAGE);
                }

                // Close resources
                ps.close();
                mconnection.createConnection().close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error during registration: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
