package javaapplication1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MY_Connection {
    public Connection createConnection() throws SQLException {
        Connection connection = null;
        
        try {
            // Chargement du driver JDBC pour MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Création de la connexion
            String url = "jdbc:mysql://localhost:3306/java_hotel_db";
            String user = "root";
            String password = ""; // Mettez votre mot de passe MySQL ici s'il y en a un
            
            connection = DriverManager.getConnection(url, user, password);
            
            System.out.println("Connexion réussie !");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Erreur lors de la connexion : " + e.getMessage());
        }
        
        return connection;
    }
}
