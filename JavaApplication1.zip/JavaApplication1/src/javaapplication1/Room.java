package javaapplication1;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javaapplication1.MY_Connection;
import javax.swing.JOptionPane;
 public class Room {
    private String number;
    private String type;
    private boolean ac;
    private boolean freeBreakfast;
    private int chargePerDay;
    private boolean occupied;
    private String customerName;
    private String contact;
    private String gender;
    
    public Room(){}
    
    public Room(String number, String type, boolean ac, boolean freeBreakfast, int chargePerDay) {
        this.number = number;
        this.type = type;
        this.ac = ac;
        this.freeBreakfast = freeBreakfast;
        this.chargePerDay = chargePerDay;
    }
    

public String GetInfo(String q) {
    String result = ""; // Initialiser une chaîne vide pour stocker les résultats
    
    try {
        MY_Connection mconnection = new MY_Connection();
        Connection conn = mconnection.createConnection();

        String query = "SELECT * FROM room WHERE type  = ? limit 1";
        PreparedStatement statement = conn.prepareStatement(query);
        statement.setString(1, q);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            this.type = resultSet.getString("type");
            this.ac = resultSet.getBoolean("ac");
            this.freeBreakfast = resultSet.getBoolean("free_breakfast");
            this.chargePerDay = resultSet.getInt("charge_per_day");
            
            // Construire la chaîne avec les résultats
            result = "Type: " + type + "\nAC: " + ac + "\nFree Breakfast: " + freeBreakfast + "\nCharge Per Day: " + chargePerDay;
        }

        resultSet.close();
        statement.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    
    return result; // Retourner la chaîne des résultats
}

    
public int getAvailibilty(String roomType) {
    int count = 0;
    try {
        PreparedStatement ps;
        ResultSet rs;
        MY_Connection mconnection = new MY_Connection();
        Connection conn = mconnection.createConnection();
        String selectQuery = "SELECT count(id) FROM room WHERE type=?";
        ps = conn.prepareStatement(selectQuery);
        ps.setString(1, roomType);
        rs = ps.executeQuery();
        
        if (rs.next()) {
            count = rs.getInt(1);
        }
        
        rs.close();
        ps.close();
        conn.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error retrieving room count: " + e.getMessage());
    }
    
    return count;
}

public int verify(int id) {
    int count = 0;
    try {
        PreparedStatement ps;
        ResultSet rs;
        MY_Connection mconnection = new MY_Connection();
        Connection conn = mconnection.createConnection();
        String selectQuery = "SELECT count(id) FROM room WHERE id=? AND availibility = 'false'";
        ps = conn.prepareStatement(selectQuery);
        ps.setInt(1, id);
        rs = ps.executeQuery();
        
        if (rs.next()) {
            count = rs.getInt(1);
        }
        
        rs.close();
        ps.close();
        conn.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error retrieving room count: " + e.getMessage());
    }
    
    return count;
}

}

    

 