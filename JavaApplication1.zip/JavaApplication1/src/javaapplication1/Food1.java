package javaapplication1;

import java.io.Serializable;

public class Food1 implements Serializable {
    int itemno;
    int quantity;
    float price;

    public Food1(int itemno, int quantity) {
        this.itemno = itemno;
        this.quantity = quantity;
        calculatePrice();
    }

    private void calculatePrice() {
        switch (itemno) {
            case 1:
                price = quantity * 3500;
                break;
            case 2:
                price = quantity * 8000;
                break;
            case 3:
                price = quantity * 9000;
                break;
            case 4:
                price = quantity * 7000;
                break;
            case 5:
                price = quantity * 12000;
                break;
            case 6:
                price = quantity * 5000;
                break;
            case 7:
                price = quantity * 15000;
                break;
            case 8:
                price = quantity * 6000;
                break;
            case 9:
                price = quantity * 8000;
                break;
            case 10:
                price = quantity * 10000;
                break;   
            
        }
    }

    public float getPrice() {
        return price;
    }
}
