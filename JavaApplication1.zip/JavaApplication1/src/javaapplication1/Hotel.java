package javaapplication1;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;



public class Hotel {
    public void Checkout(int id) {
        try {
            MY_Connection mconnection = new MY_Connection();
            Connection conn = mconnection.createConnection();
            String query = "UPDATE room SET availibility = 'true' WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(null, "Your chekout is registred !");
        } catch (SQLException e) {
            // Gérer les erreurs de base de données
            JOptionPane.showMessageDialog(null, "Erreur lors de la mise à jour de la disponibilité : " + e.getMessage());
        }
    }
    public int getRandomRoomId(String Type) {
    int roomId = 0;
    try {
        PreparedStatement ps;
        ResultSet rs;
        MY_Connection mconnection = new MY_Connection();
        Connection conn = mconnection.createConnection();
        String selectQuery = "SELECT id FROM room WHERE type = ? AND availibility= 'true' ORDER BY RAND() LIMIT 1";
        ps = conn.prepareStatement(selectQuery);
        ps.setString(1, Type);
        rs = ps.executeQuery();
        
        if (rs.next()) {
            roomId = rs.getInt("id");
        }
        
        rs.close();
        ps.close();
        conn.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error retrieving random room ID: " + e.getMessage());
    }
    
    return roomId;
}
    public void changeAvailibilityToFalse(int roomId) {
            try {
            MY_Connection mconnection = new MY_Connection();
            Connection conn = mconnection.createConnection();
            String query = "UPDATE room SET availibility = 'false' WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, roomId);
            pstmt.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(null, "Your chekin is registred !");
        } catch (SQLException e) {
            // Gérer les erreurs de base de données
            JOptionPane.showMessageDialog(null, "Erreur lors de la mise à jour de la disponibilité : " + e.getMessage());
        }
    }
    public static String CustDetails(int roomId) {
        String output = "";
        
        try {
            MY_Connection mconnection = new MY_Connection();
            Connection conn = mconnection.createConnection(); 
            String query = "SELECT type FROM room WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, roomId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                String roomType = rs.getString("type");
                String name1, contact1, gender1;
                    name1 = JOptionPane.showInputDialog(null, "Enter customer name:");
                    contact1 = JOptionPane.showInputDialog(null, "Enter contact number:");
                    gender1 = JOptionPane.showInputDialog(null, "Enter gender:");
                    output += "Customer 1:\nName: " + name1 + "\nContact: " + contact1 + "\nGender: " + gender1+ "\n";

                if (roomType.equals("standard_double") || roomType.equals("luxury_double"))  {
                     String name2, contact2, gender2;
                    name2 = JOptionPane.showInputDialog(null, "Enter customer name:");
                    contact2 = JOptionPane.showInputDialog(null, "Enter contact number:");
                    gender2 = JOptionPane.showInputDialog(null, "Enter gender:");
                    output += "Customer 2:\nName: "+ name2 + "\nContact: " + contact2+ "\nGender: " + gender2 + "\n";
                }
            } else {
                output = "Room not found.";
            }
            conn.close();

        } catch (SQLException e) {
            output = "Error: " + e.getMessage();
        }
        

        
        return output;
    }
    
}

