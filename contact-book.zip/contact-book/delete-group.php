<?php
session_start();

if (isset($_SESSION['user_id'])) {
    require_once "db_connect.php";

    if (isset($_GET['id'])) {
        $groupId = $_GET['id'];
        $user_id = $_SESSION['user_id'];

        // Check if the group has any associated contacts
        $check_contacts_query = "SELECT COUNT(*) as count FROM `-contact-` WHERE `group_id` = :group_id AND `user_id` = :user_id";
        $stmt = $conn->prepare($check_contacts_query);
        $stmt->bindParam(':group_id', $groupId);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result['count'] > 0) {
            $_SESSION['error'] = "Cannot delete group. Group has associated contacts.";
            header('Location: groups.php');
            exit();
        }

        $delete_query = "DELETE FROM `-group-` WHERE `id` = :group_id AND `user_id` = :user_id";
        $stmt = $conn->prepare($delete_query);
        $stmt->bindParam(':group_id', $groupId);
        $stmt->bindParam(':user_id', $user_id);

        try {
            if ($stmt->execute()) {
                $_SESSION['success'] = "Group deleted successfully";
            } else {
                $_SESSION['error'] = "Failed to delete group";
            }
        } catch (PDOException $ex) {
            $_SESSION['error'] = "Error deleting group: " . $ex->getMessage();
        }

        header('Location: groups.php');
        exit();
    } else {
        $_SESSION['error'] = "Group ID not provided";
        header('Location: groups.php');
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
?>