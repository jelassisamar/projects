<?php
session_start();

if (isset($_SESSION['user_id'])) {
    require_once "db_connect.php";

    if (isset($_GET['id'])) {
        $contactId = $_GET['id'];
        $user_id = $_SESSION['user_id'];

        $delete_query = "DELETE FROM `-contact-` WHERE `id` = :contact_id AND `user_id` = :user_id";
        $stmt = $conn->prepare($delete_query);
        $stmt->bindParam(':contact_id', $contactId);
        $stmt->bindParam(':user_id', $user_id);

        try {
            if ($stmt->execute()) {
                $_SESSION['success'] = "Contact deleted successfully";
            } else {
                $_SESSION['error'] = "Failed to delete contact";
            }
        } catch (PDOException $ex) {
            $_SESSION['error'] = "Error deleting contact: " . $ex->getMessage();
        }

        header('Location: contacts.php');
        exit();
    } else {
        $_SESSION['error'] = "Contact ID not provided";
        header('Location: contacts.php');
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
?>