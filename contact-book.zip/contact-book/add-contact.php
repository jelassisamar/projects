<?php
    session_start();
    if (isset($_SESSION['user_id'])){
        echo $_SESSION['name'];
    }
    else {
        header("Location: login.php");
        exit();
    }

    require_once "db_connect.php";

    $user_id=$_SESSION['user_id'];

    $sql ="SELECT * FROM `-group-` WHERE `user_id`=:user_id";
    $stmt=$conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);

    $stmt->execute();

    $options='';

    while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
        $options=$options.'<option value="'.$row['id'].'" name="group_id">'
        .$row['name'].'</option>';
    }




    if(isset($_POST['submit'])){

        $name=$_POST['name'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
        $address=$_POST['address'];
        $group=$_POST['group'];
        $user_id=$_SESSION['user_id'];


        $stmt=$conn->prepare('INSERT INTO `-contact-`( `name`, `email`, `phone`, `address`, `group_id`, `user_id`) VALUES (:name,:email,:phone,:address,:group_id,:user_id)');
        
    
        try{
            if($stmt->execute(array(
                ':name'=>$name ,
                ':email'=>$email,
                ':phone'=>$phone,
                ':address'=>$address,
                ':group_id'=>$group,
                ':user_id'=>$user_id,
                ))){
                $_SESSION['success']="new contact added";
                header('Location: add-contact.php');
                exit();
            }
            else{
                $_SESSION['error']="contact not added";
                header('Location: add-contact.php');
                exit();
            }
        }catch(PDOException $ex){
            $_SESSION['error']="contact not added" . $ex->getMessage();
        }

        unset($_SESSION['success']);
        unset($_SESSION['error']);
        header('Location: add-contact.php');
        exit();

    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Group</title>
    <link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <link rel="stylesheet" type="text/css" href="form-styles.css">
    <style>
        .alert {
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            position: relative;
            width: 80%;
            margin: 0 auto;
            font-size: 20px;
            margin-bottom: 15px;
        }

        .alert.success{
            background-color: #dff0f8;
            border: 2px solid #3c763d;
            color: #333; /* Add text color for error alerts */
        }

        .alert.error {
            background-color: rgba(236, 77, 43, 0.2);
            border: 2px solid #EF9400;
            color: #333; /* Add text color for success alerts */
        }

        .close {
            position: absolute;
            top: 5px;
            right: 5px;
            padding: 1px 4px;
            cursor: pointer;
            border-radius: 25%;
            border: 1px solid #535c68;
            transition: background-color 0.2s ease-in-out;
        }

        .close:hover {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Add contact</h1>
    <form method="post" action="#">
    <?php
    if (isset($_SESSION['error'])) {
        echo '<div class="alert error"><p>' . $_SESSION['error'] . '</p><span class="close">&times;</span></div>';
        unset($_SESSION['error']);
    } elseif (isset($_SESSION['success'])) {
        echo '<div class="alert success"><p>' . $_SESSION['success'] . '</p><span class="close">&times;</span></div>';
    }
    unset($_SESSION['success']);
    unset($_SESSION['error']);
?>
        <label for="name">Name:</label>
        <input type="text" name="name" required>

        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <label for="phone">Phone:</label>
        <input type="tel" name="phone" required>

        <label for="address">Address:</label>
        <textarea rows="4" name="address" required></textarea>

        <label for="group">Group:</label>
        <select name="group" id="group" required>
            <option value="">--Select a Group--</option>
            <?php
                echo $options; 
            ?>
        </select>


        
        <input type="submit" name="submit" value="Add Contact">
        
    </form>
    <button id="returnButton">Retour</button>

    <script>
         document.querySelectorAll(".close").forEach(function(closeButton) {
            closeButton.addEventListener("click", function() {
                closeButton.parentElement.style.display = "none";
            });
        });
    </script>

<script>
document.getElementById("returnButton").addEventListener("click", function() {
    window.location.href = "contacts.php";
});
</script>

</body>
</html>