<?php
session_start(); // Start the session

require_once "db_connect.php";

if (isset($_POST['submit'])) {
    $fullname = filter_var($_POST['fullname'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = filter_var($_POST['password'], FILTER_SANITIZE_STRING);

    $email_check_query = "SELECT * FROM `user` WHERE `email` = :email";
    $stmt = $conn->prepare($email_check_query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        header("Location:register.php");
        $_SESSION['error'] = "Email Address already exists";
        exit();
    }

    if (strlen($password) < 8) {
        header("Location:register.php");
        $_SESSION['error'] = "Password should be at least 8 characters long";
        exit();
    }

    unset($_SESSION['error']);

    $password = password_hash($password, PASSWORD_BCRYPT);

    $insert_query = "INSERT INTO `user` (`fullname`, `email`, `password`) VALUES (:fullname, :email, :password)";
    $stmt = $conn->prepare($insert_query);
    $stmt->bindParam(':fullname', $fullname);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $password);

    try{
        if( $stmt->execute())
        {   header("Location:register.php");
            $_SESSION['success'] ='account created successfully';
            exit();
        }else{
            header("Location:register.php");
            $_SESSION['error'] ='account not created';
            

        }
        
    }catch(PDOException $ex){
        $_SESSION['eroor'] ='account not created - ' .$ex ->getMessage();
    }
    unset($_SESSION['success']);
    unset($_SESSION['error']);
   


    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="lg_rg_style.css">
    <title>Sign Up Form</title>
    <style>
        .alert {
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            position: relative;
            width: 100%;
            margin: 0 auto;
            font-size: 20px;
            margin-bottom: 15px;
        }

        .alert.success{
            background-color: #dff0f8;
            border: 2px solid #3c763d;
            color: #333; /* Add text color for error alerts */
        }

        .alert.error {
            background-color: rgba(236, 77, 43, 0.2);
            border: 2px solid #EF9400;
            color: #333; /* Add text color for success alerts */
        }

        .close {
            position: absolute;
            top: 5px;
            right: 5px;
            padding: 1px 4px;
            cursor: pointer;
            border-radius: 25%;
            border: 1px solid #535c68;
            transition: background-color 0.2s ease-in-out;
        }

        .close:hover {
            background-color: #f2f2f2;
        }
    </style>

</head>
<body>
    <div class="signup-wrapper">
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" class="signup-form">
        <?php


if (isset($_SESSION['error'])) {
    echo '<div class="alert error"><p>' . $_SESSION['error'] . '</p><span class="close">&times;</span></div>';
    unset($_SESSION['error']);
} elseif (isset($_SESSION['success'])) {
    echo '<div class="alert success"><p>' . $_SESSION['success'] . '</p><span class="close">&times;</span></div>';
}


unset($_SESSION['success']);
unset($_SESSION['error']);
?>
            <h1>Sign Up</h1>

            <div class="form-group">
                <label for="name">Fullname:</label>
                <input type="text" id="name" name="fullname" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>

            <div class="form-group">



            
                <button type="submit" name="submit">Signup</button>
            </div>

            <p>Already have an account? <a href="login.php">Login</a></p>
        </form>
    </div>


    <script>
         document.querySelectorAll(".close").forEach(function(closeButton) {
            closeButton.addEventListener("click", function() {
                closeButton.parentElement.style.display = "none";
            });
        });
    </script>

</body>
</html>

