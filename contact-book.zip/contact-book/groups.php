<?php
    session_start();
    if (isset($_SESSION['user_id'])){
        echo $_SESSION['name'];
    }
    else {
        header("Location: login.php");
        exit();
    }
    require_once "db_connect.php";

    $user_id=$_SESSION['user_id'];

    $sql ="SELECT * FROM `-group-` WHERE `user_id`=:user_id";
    $stmt=$conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);

    $stmt->execute();


?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Groups</title>
    <link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <link rel="stylesheet" type="text/css" href="contacts-style.css">
    <style>
        .alert {
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            position: relative;
            width: 80%;
            margin: 0 auto;
            font-size: 20px;
            margin-bottom: 15px;
        }

        .alert.success{
            background-color: #dff0f8;
            border: 2px solid #3c763d;
            color: #333; /* Add text color for error alerts */
        }

        .alert.error {
            background-color: rgba(236, 77, 43, 0.2);
            border: 2px solid #EF9400;
            color: #333; /* Add text color for success alerts */
        }

        .close {
            position: absolute;
            top: 5px;
            right: 5px;
            padding: 1px 4px;
            cursor: pointer;
            border-radius: 25%;
            border: 1px solid #535c68;
            transition: background-color 0.2s ease-in-out;
        }

        .close:hover {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="menu">
            <ul>
                <li><a href ="groups.php">Groups</a></li>
                <li><a href ="contacts.php">Contacts</a></li>
                <li><a href ="logout.php">Logout</a></li>
            </ul>
            <h1>My Groups</h1>

            <?php


if (isset($_SESSION['error'])) {
    echo '<div class="alert error"><p>' . $_SESSION['error'] . '</p><span class="close">&times;</span></div>';
    unset($_SESSION['error']);
} elseif (isset($_SESSION['success'])) {
    echo '<div class="alert success"><p>' . $_SESSION['success'] . '</p><span class="close">&times;</span></div>';
}


unset($_SESSION['success']);
unset($_SESSION['error']);
?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Group Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                    <?php
                    while($row = $stmt->fetch(PDO::FETCH_ASSOC))
                    {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['name'] . "</td>";

                        echo "<td>";
                        echo"<a href='edit-group.php?id=" . $row['id'] . "' class='icon icon-edit'  title ='edit'></a>";
                        echo"<a href='delete-group.php?id=" . $row['id'] . "'  class='icon icon-delete'  title ='delete'></a>";

                        echo "</td>"; 
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>

            <div class="icon-add-container">
                <a href="add-group.php" class="icon icon-add"  title ="add group">
                    <i class="fas fa-plus"></i>
                </a>
            </div>

        </nav>
    </div>
</body> 
</html>