<?php
    session_start();
    if (isset($_SESSION['user_id'])){
        echo $_SESSION['name'];
    }
    else {
        header("Location: login.php");
        exit();
    }

    require_once "db_connect.php";

    $groupId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($groupId === false){
    die("Invalid Group ID");
}



$name = '';

$select_query = "SELECT * FROM `-group-` WHERE `id`=:group_id";

$stmt = $conn->prepare($select_query); 
$stmt->bindParam(':group_id', $groupId); 
$stmt->execute();

$result = $stmt->fetch(PDO::FETCH_ASSOC);

if($result){
    $name = $result['name'];
}




    if(isset($_POST['submit'])){

        $name=$_POST['group-name'];
        $user_id=$_SESSION['user_id'];


        $stmt=$conn->prepare('UPDATE `-group-` SET `name`=:name WHERE `id`=:id');
    
        try{
            if($stmt->execute(array(':name'=>$name, ':id'=>$groupId))){
                $_SESSION['success']="group name updated";
                header('Location: edit-group.php');
                exit();
            }
            else{
                $_SESSION['error']="group name not updated";
                header('Location: edit-group.php');
                exit();
            }
        }catch(PDOException $ex){
            $_SESSION['error']="group name not updated - " . $ex->getMessage();
        }

        unset($_SESSION['success']);
        unset($_SESSION['error']);
        header('Location: edit-group.php');
        exit();

    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Group</title>
    <link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="form-styles.css">
    <style>
        .alert {
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            position: relative;
            width: 80%;
            margin: 0 auto;
            font-size: 20px;
            margin-bottom: 15px;
        }

        .alert.success{
            background-color: #dff0f8;
            border: 2px solid #3c763d;
            color: #333; /* Add text color for error alerts */
        }

        .alert.error {
            background-color: rgba(236, 77, 43, 0.2);
            border: 2px solid #EF9400;
            color: #333; /* Add text color for success alerts */
        }

        .close {
            position: absolute;
            top: 5px;
            right: 5px;
            padding: 1px 4px;
            cursor: pointer;
            border-radius: 25%;
            border: 1px solid #535c68;
            transition: background-color 0.2s ease-in-out;
        }

        .close:hover {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>


    <h1>Edit Group</h1>
    
    <form method="post" action="#">
    <?php


if (isset($_SESSION['error'])) {
    echo '<div class="alert error"><p>' . $_SESSION['error'] . '</p><span class="close">&times;</span></div>';
    unset($_SESSION['error']);
} elseif (isset($_SESSION['success'])) {
    echo '<div class="alert success"><p>' . $_SESSION['success'] . '</p><span class="close">&times;</span></div>';
}


unset($_SESSION['success']);
unset($_SESSION['error']);
?>
        <label for="group-name">Group Name:</label>
        <input type="text" name="group-name"  id="group-name" value="<?php echo $name; ?>" required>
        
        <input type="submit" name="submit" value="Edit Group">
    </form>

    <button id="returnButton">Retour</button>
    <script>
         document.querySelectorAll(".close").forEach(function(closeButton) {
            closeButton.addEventListener("click", function() {
                closeButton.parentElement.style.display = "none";
            });
        });
    </script>
    
    <script>
            document.getElementById("returnButton").addEventListener("click", function() {
                window.location.href = "groups.php";});
    </script>
</body>
</html>