<?php
    session_start();
    if (isset($_SESSION['user_id'])){
        echo $_SESSION['name'];
    }
    else {
        header("Location: login.php");
        exit();
    }


    require_once "db_connect.php";

    $user_id=$_SESSION['user_id'];


    $sql = "SELECT `-contact-`.`id`, `-contact-`.`name`, `-contact-`.`email`, `-contact-`.`phone`,
    `-contact-`.`address`, `-group-`.`name` as `group`
    FROM `-contact-`
    INNER JOIN `-group-`
    ON `-contact-`.`group_id` = `-group-`.`id`
    WHERE `-contact-`.`user_id` = :user_id";

$stmt=$conn->prepare($sql);
$stmt->bindParam(':user_id', $user_id);

$stmt->execute();
?> 
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Conatcts</title>
    <link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    
    <link rel="stylesheet" type="text/css" href="contacts-style.css">
    <style>
        .alert {
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            position: relative;
            width: 80%;
            margin: 0 auto;
            font-size: 20px;
            margin-bottom: 15px;
        }

        .alert.success{
            background-color: #dff0f8;
            border: 2px solid #3c763d;
            color: #333; /* Add text color for error alerts */
        }

        .alert.error {
            background-color: rgba(236, 77, 43, 0.2);
            border: 2px solid #EF9400;
            color: #333; /* Add text color for success alerts */
        }

        .close {
            position: absolute;
            top: 5px;
            right: 5px;
            padding: 1px 4px;
            cursor: pointer;
            border-radius: 25%;
            border: 1px solid #535c68;
            transition: background-color 0.2s ease-in-out;
        }

        .close:hover {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="menu">
            <ul>
                <li><a href ="groups.php">Groups</a></li>
                <li><a href ="contacts.php">Contacts</a></li>
                <li><a href ="logout.php">Logout</a></li>
            </ul>
            <h1>My Contacts</h1>

            <div class="search">
                <form action="#" method="post">
                    <input type="search" name="search" placeholder="Search contacts ...">
                    <button type="submit" name="search-submit">search</button>
                </form>
            </div>
            <?php


if (isset($_SESSION['error'])) {
    echo '<div class="alert error"><p>' . $_SESSION['error'] . '</p><span class="close">&times;</span></div>';
    unset($_SESSION['error']);
} elseif (isset($_SESSION['success'])) {
    echo '<div class="alert success"><p>' . $_SESSION['success'] . '</p><span class="close">&times;</span></div>';
}


unset($_SESSION['success']);
unset($_SESSION['error']);
?>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Group</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    while($row = $stmt->fetch(PDO::FETCH_ASSOC))
                    {
                        echo "<tr>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>" . $row['phone'] . "</td>";
                        echo "<td>" . $row['address'] . "</td>";
                        echo "<td>" . $row['group'] . "</td>";

                        echo "<td>";

                        echo"<a href='edit-contact.php?id=". $row['id'] ."'class='icon icon-edit'  title ='edit'></a>";
                        echo"<a href='delete-contact.php?id=" . $row['id'] . "' class='icon icon-delete'  title ='delete'></a>";

                        echo "</td>"; 
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>

            <div class="icon-add-container">
                <a href="add-contact.php" class="icon icon-add"  title ="add contact">
                    <i class="fas fa-plus"></i>
                </a>
            </div>

        </nav>
    </div>
</body>
</html>

