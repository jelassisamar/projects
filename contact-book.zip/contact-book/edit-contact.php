<?php
session_start();
if (isset($_SESSION['user_id'])){
    echo $_SESSION['name'];
}
else {
    header("Location: login.php");
    exit();
}

require_once "db_connect.php";

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM `-group-` WHERE `user_id` = :user_id";
$stmt2 = $conn->prepare($sql);
$stmt2->bindParam(':user_id', $user_id);
$stmt2->execute();

$options = '';

$contactId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($contactId === false){
    die("Invalid contact ID");
}

$name = '';
$email = '';
$phone = '';
$address = '';
$groupId = '';

$select_query = "SELECT * FROM `-contact-` WHERE `id` = :contact_id";

$stmt = $conn->prepare($select_query);
$stmt->bindParam(':contact_id', $contactId);
$stmt->execute();

$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result){
    $name = $result['name'];
    $email = $result['email'];
    $phone = $result['phone'];
    $address = $result['address'];
    $groupId = $result['group_id'];

    while ($row = $stmt2->fetch(PDO::FETCH_ASSOC)) {
        $selected = ($groupId == $row['id']) ? 'selected="selected"' : '';
        $options .= '<option value="' . $row['id'] . '" ' . $selected . '>' . $row['name'] . '</option>';
    }
}

if (isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $group = $_POST['group'];

    $stmt = $conn->prepare('UPDATE `-contact-` SET `name` = :name, `email` = :email, 
        `phone` = :phone, `address` = :address, `group_id` = :group_id,
        `user_id` = :user_id WHERE `id` = :id');

    try {
        if ($stmt->execute(array(
            ':name' => $name,
            ':email' => $email,
            ':phone' => $phone,
            ':address' => $address,
            ':group_id' => $group,
            ':id' => $contactId,
            ':user_id' => $user_id
        ))) {
            $_SESSION['success'] = "Contact updated";
            header('Location: add-contact.php');
            exit();
        } else {
            $_SESSION['error'] = "Contact not updated";
            header('Location: edit-contact.php');
            exit();
        }
    } catch (PDOException $ex) {
        $_SESSION['error'] = "Contact not updated: " . $ex->getMessage();
    }

    unset($_SESSION['success']);
    unset($_SESSION['error']);
    header('Location: edit-contact.php');
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Group</title>
    <link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <link rel="stylesheet" type="text/css" href="form-styles.css">
    <style>
        .alert {
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            position: relative;
            width: 80%;
            margin: 0 auto;
            font-size: 20px;
            margin-bottom: 15px;
        }

        .alert.success{
            background-color: #dff0f8;
            border: 2px solid #3c763d;
            color: #333; /* Add text color for error alerts */
        }

        .alert.error {
            background-color: rgba(236, 77, 43, 0.2);
            border: 2px solid #EF9400;
            color: #333; /* Add text color for success alerts */
        }

        .close {
            position: absolute;
            top: 5px;
            right: 5px;
            padding: 1px 4px;
            cursor: pointer;
            border-radius: 25%;
            border: 1px solid #535c68;
            transition: background-color 0.2s ease-in-out;
        }

        .close:hover {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Edit contact</h1>
    <form method="post" action="#">
    <?php
    if (isset($_SESSION['error'])) {
        echo '<div class="alert error"><p>' . $_SESSION['error'] . '</p><span class="close">&times;</span></div>';
        unset($_SESSION['error']);
    } elseif (isset($_SESSION['success'])) {
        echo '<div class="alert success"><p>' . $_SESSION['success'] . '</p><span class="close">&times;</span></div>';
    }
    unset($_SESSION['success']);
    unset($_SESSION['error']);
?>
        <label for="name">Name:</label>
        <input type="text" name="name" value="<?php echo $name ?> "required>

        <label for="email">Email:</label>
        <input type="email" name="email"value="<?php echo $email ?> " required>

        <label for="phone">Phone:</label>
        <input type="tel" name="phone"value="<?php echo $phone ?> " required>

        <label for="address">Address:</label>
        <textarea rows="4" name="address"required><?php echo $address ?></textarea>

        <label for="group">Group:</label>
        <select name="group" id="group" required>
            <option value="">--Select a Group--</option>
            <?php
                echo $options; 
            ?>
        </select>


        
        <input type="submit" name="submit" value="Edit Contact">
        
    </form>
    <button id="returnButton">Retour</button>

    <script>
         document.querySelectorAll(".close").forEach(function(closeButton) {
            closeButton.addEventListener("click", function() {
                closeButton.parentElement.style.display = "none";
            });
        });
    </script>

<script>
document.getElementById("returnButton").addEventListener("click", function() {
    window.location.href = "contacts.php";
});
</script>

</body>
</html>