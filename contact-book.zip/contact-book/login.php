<?php
session_start(); 

require_once "db_connect.php";

if (isset($_SESSION['user_id'])) {
    header("Location: contacts.php");
    exit();
}

$error_msg = ""; 

if (isset($_POST['submit'])) {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = filter_var($_POST['password'], FILTER_SANITIZE_STRING);

    $stmt = $conn->prepare("SELECT * FROM `user` WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        if (password_verify($password, $result['password'])) {
            $_SESSION['user_id'] = $result['id'];
            $_SESSION['name'] = $result['fullname'];
            header("Location: contacts.php");
            exit();
        } else {
            $error_msg = "Incorrect email or password";
        }
    } else {
        $error_msg = "Incorrect email or password";
    }

    $conn = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="lg_rg_style.css">
    <title>Login Form</title>
</head>
<body>
    <div class="signup-wrapper">
        <form action="#" method="post" class="signup-form">
            <h1>Login</h1>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>

            <?php if (!empty($error_msg)) { ?>
                <p style="color: red; margin-top:5px; margin-bottom:5px;"><?php echo $error_msg; ?></p>
            <?php } ?>

            <div class="form-group">
                <button type="submit" name="submit">Login</button>
            </div>

            <p>Don't have an account yet? <a href="register.php">Signup</a></p>
        </form>
    </div>
</body>
</html>